package com.example.mypadel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.BreakIterator;

public class MainActivity extends AppCompatActivity {


    // variables que detallan el numero de sets
    int setsJ1=0;
    int setsJ2=0;
    // variables que detallan el numero de juegos
    int juegosJ1S1=0;
    int juegosJ1S2=0;
    int juegosJ1S3=0;

    int juegosJ2S1=0;
    int juegosJ2S2=0;
    int juegosJ2S3=0;
    //variable que indica los set necesarios para ganar
    int setsParaGanar=2;
    //declaramos las variables
    Button btPuntoEquipo1,btPuntoEquipo2;

    TextView textViewMarcador1;

    TextView textViewMarcador2;
    TextView textView1_1,textView1_2,textView1_3,textView2_1,textView2_2,textView2_3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //inicia las referencias de las vistas. metodo privado abajo
        initReferences();

        // generamos los listeners de los botones

        btPuntoEquipo1.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                String punto = textViewMarcador1.getText().toString();

                switch (punto) {
                    case "00":
                        textViewMarcador1.setText("15");
                        break;
                    case "15":
                        textViewMarcador1.setText("30");
                        break;
                    case "30":
                        textViewMarcador1.setText("40");
                        break;
                    case "40":
                        if (!textViewMarcador2.getText().toString().equals("40") && !textViewMarcador2.getText().toString().equals("V")) {
                            juegosJ1S1++;
                            if(juegosJ1S1<7 ) {
                                textView1_1.setText(String.valueOf(juegosJ1S1));
                                textViewMarcador1.setText("00");
                                textViewMarcador2.setText("00");

                            }
                             if(Integer.parseInt(textView1_1.getText().toString())==6){
                                 juegosJ1S2++;
                                 textView1_2.setText(String.valueOf(juegosJ1S2));
                                textViewMarcador1.setText("00");
                                textViewMarcador2.setText("00");
                            } if(Integer.parseInt(textView1_2.getText().toString())==6){
                                 juegosJ1S3++;
                                textView1_3.setText(String.valueOf(juegosJ1S3));
                                textViewMarcador1.setText("00");
                                textViewMarcador2.setText("00");
                            }

                        } else if (textViewMarcador2.getText().toString().equals("V")) {
                            textViewMarcador1.setText("40");
                            textViewMarcador2.setText("40");
                        } else {
                            textViewMarcador1.setText("V");
                        }
                        break;
                    case "V":
                        juegosJ1S1++;
                        textView1_1.setText(String.valueOf(juegosJ1S1));
                        textView1_1.setText("1");
                        textViewMarcador1.setText("00");
                        textViewMarcador2.setText("00");

                        break;
                }

            }
        });

        btPuntoEquipo2.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                String punto = textViewMarcador2.getText().toString();

                switch (punto) {
                    case "00":
                        textViewMarcador2.setText("15");
                        break;
                    case "15":
                        textViewMarcador2.setText("30");
                        break;
                    case "30":
                        textViewMarcador2.setText("40");
                        break;
                    case "40":
                        if (!textViewMarcador1.getText().toString().equals("40") && !textViewMarcador1.getText().toString().equals("V")) {
                            juegosJ2S2++;
                            textView2_1.setText(String.valueOf(juegosJ2S2));
                            textViewMarcador2.setText("00");
                            textViewMarcador1.setText("00");
                        } else if (textViewMarcador1.getText().toString().equals("V")) {
                            textViewMarcador2.setText("40");
                            textViewMarcador1.setText("40");
                        } else {
                            textViewMarcador2.setText("V");
                        }
                        break;
                    case "V":
                        juegosJ2S2++;
                        textView2_1.setText(String.valueOf(juegosJ2S2));
                        textView2_1.setText("1");
                        textViewMarcador2.setText("00");
                        textViewMarcador1.setText("00");
                        break;
                }
            }
        });

    }


    private void initReferences(){
        btPuntoEquipo1=findViewById(R.id.puntoJ1);
        btPuntoEquipo2=findViewById(R.id.puntoJ2);
        textViewMarcador1=findViewById(R.id.marcadorJ1);
        textViewMarcador2=findViewById(R.id.marcadorJ2);
        textView1_1=findViewById(R.id.set1_1);
        textView1_2=findViewById(R.id.set1_2);
        textView1_3=findViewById(R.id.set1_3);
        textView2_1=findViewById(R.id.set2_1);
        textView2_2=findViewById(R.id.set2_2);
        textView2_3=findViewById(R.id.set2_3);


    }
}